use master;
Create database Proyecto092;
use Proyecto092;
CREATE TABLE Empleado
(  
    Codigodeempleado int NOT NULL  
    ,Nombre varchar NOT NULL   
);
select * from Empleado;
